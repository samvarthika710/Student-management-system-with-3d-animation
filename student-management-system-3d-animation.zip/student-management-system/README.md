# Student Management System — 3D CRUD Web Application

A complete, animated, interactive single-page Student Management System built to the
"Complete CRUD-Based Web Application Development" SOP. Pure HTML + CSS + JavaScript with
three.js for the 3D background — **no build step, no npm install, no server required.**

---

## 1. Run it in VS Code

### Option A — Live Server (recommended)
1. Open the `student-management-system` folder in VS Code (`File → Open Folder…`).
2. Install the extension **Live Server** (publisher: Ritwick Dey).
3. Right-click `index.html` → **Open with Live Server**.
4. The app opens at `http://127.0.0.1:5500`.

### Option B — any static server
```bash
# Python 3 (already installed on most machines)
python -m http.server 5500
# then open http://localhost:5500

# or Node
npx serve .
```

### Option C — just double-click
`index.html` works when opened directly from the file system too. Fonts and three.js
are loaded from a CDN, so keep an internet connection for the full look. Without it the
app still runs — it falls back to system fonts and skips the 3D background.

---

## 2. Project structure

```
student-management-system/
├── index.html                  # markup: header, nav, 6 tabs, modals
├── css/
│   └── style.css               # design tokens, glassmorphism, all 3D/CSS animation
├── js/
│   ├── scene.js                # three.js particle + wireframe background, mouse parallax
│   └── app.js                  # data layer, REST API layer, validation, UI, test runner
├── docs/
│   ├── API.md                  # endpoint reference + request/response examples
│   └── BACKEND_REFERENCE.md    # Django REST Framework & Spring Boot equivalents
└── README.md
```

## 3. Features (mapped to the SOP)

| SOP section | Where it lives |
|---|---|
| §7.4 Frontend development | `index.html`, `css/style.css` — responsive layout, forms, card grid, search/filter |
| §7.5 Backend / service logic | `js/app.js` → `api()`, `validate()`, `dup()`, `clean()` |
| §7.6 REST API implementation | `api()` router: POST/GET/PUT/PATCH/DELETE on `/api/students/` |
| §7.7 Frontend–backend integration | `save()`, `askDelete()`, API Console tab — JSON in, JSON out |
| §8 CRUD functionality | Students tab: create, read, update, delete with live UI refresh |
| §9 Validation | `validate()` (server-side) + per-field error rendering (client-side) |
| §10 Testing | Testing tab — 20 automated cases with pass/fail animation |
| §7.3 Database design | `docs/API.md` + the ER diagram in the Documentation tab |
| §17 Demonstration checklist | Documentation tab, persisted to `localStorage` |
| §18 Architecture | Architecture tab — rotating 5-layer 3D stack with a travelling request packet |

### 3D / animation highlights
- three.js background: 1,500-point starfield, wireframe icosahedron / torus knot / octahedron / cylinder / cube, camera parallax that follows the pointer.
- Student records are 3D flip cards — hover tilts them, click rotates them 180° to reveal details and the Edit/Delete controls.
- Spinning cube preloader, rotating cube logo, 3D modal entry, tilting stat cards with count-up animation, rotating architecture stack, sliding toasts, animated progress bars.
- Light/dark palettes with a manual toggle (remembered in `localStorage`).

## 4. Data storage

Records live in `js/app.js` (`DB.students`) and are saved to `localStorage` under the key
`sms.v1`, so they survive a page reload. The `initStore()` function also contains an
optional cloud-sync branch used when the page is hosted as a Claude artifact; running
locally, that branch is skipped automatically and localStorage is used.

To swap in a **real backend**, replace the local `api(method, path, body)` function with
a `fetch` call — the signature and the JSON shapes are already identical:

```js
async function api(method, path, body) {
  const res = await fetch('http://localhost:8000' + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = res.status === 204 ? null : await res.json();
  return { status: res.status, data };
}
```
Then make every caller `await` it. See `docs/BACKEND_REFERENCE.md` for the Django REST
Framework and Spring Boot code that serves these exact routes.

## 5. Student entity

| Field | Type | Rule |
|---|---|---|
| `id` | integer | auto-increment primary key |
| `name` | string | required, min 3 characters |
| `rollNo` | string | required, unique |
| `email` | string | required, unique, valid email format |
| `department` | enum | CSE / IT / ECE / EEE / MECH / CIVIL / AIML / MBA |
| `year` | integer | 1–4 |
| `marks` | number | 0–100 |
| `phone` | string | exactly 10 digits |
| `status` | enum | Active / Inactive |

## 6. Demo script for evaluation

1. Students tab → **Seed demo data** (8 POSTs, watch the log on the Dashboard).
2. **+ New Student** → submit an empty form to show field-level validation (400), then a duplicate roll number (409), then a valid record (201).
3. Click a card to flip it → **Edit** → change marks → save (200).
4. **Delete** → confirm (204) and show the record gone.
5. Search and filter to show §9 search/filter support.
6. API Console → run GET, POST, PUT, DELETE, plus an invalid ID for 404.
7. Testing tab → **Run all test cases** → 20/20 green.
8. Architecture and Documentation tabs for the viva.

## 7. Git

```bash
git init
git add .
git commit -m "feat: student management system with full CRUD, REST API layer and tests"
```
No secrets or credentials are present in this codebase; `.gitignore` excludes editor and
OS artifacts.
