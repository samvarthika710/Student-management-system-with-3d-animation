# Backend Reference — serving the same API

The frontend's `api()` function in `js/app.js` implements the SOP's routes locally so the
app is demonstrable with zero setup. Below is the equivalent real backend for the same
contract; swap `api()` for a `fetch` wrapper (see README §4) and the frontend needs no
other change.

---

## A. Django + Django REST Framework

### Install
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install django djangorestframework django-cors-headers
django-admin startproject config .
python manage.py startapp students
```

### students/models.py
```python
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.db import models

class Student(models.Model):
    DEPARTMENTS = [(d, d) for d in
                   ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL", "AIML", "MBA"]]
    STATUSES = [("Active", "Active"), ("Inactive", "Inactive")]

    name = models.CharField(max_length=80)
    roll_no = models.CharField(max_length=20, unique=True)
    email = models.EmailField(max_length=120, unique=True)
    department = models.CharField(max_length=30, choices=DEPARTMENTS)
    year = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)])
    marks = models.DecimalField(max_digits=5, decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(100)])
    phone = models.CharField(max_length=10,
        validators=[RegexValidator(r"^\d{10}$", "Phone must be exactly 10 digits.")])
    status = models.CharField(max_length=10, choices=STATUSES, default="Active")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.roll_no} — {self.name}"
```

### students/serializers.py
```python
from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    rollNo = serializers.CharField(source="roll_no", max_length=20)
    createdAt = serializers.DateTimeField(source="created_at", read_only=True)
    updatedAt = serializers.DateTimeField(source="updated_at", read_only=True)

    class Meta:
        model = Student
        fields = ["id", "name", "rollNo", "email", "department",
                  "year", "marks", "phone", "status", "createdAt", "updatedAt"]

    def validate_name(self, v):
        if len(v.strip()) < 3:
            raise serializers.ValidationError("Name must be at least 3 characters.")
        return v.strip()
```

### students/views.py
```python
from django.db.models import Avg, Count, Q
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Student
from .serializers import StudentSerializer

class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        search = self.request.query_params.get("search")
        dept = self.request.query_params.get("dept")
        if search:
            qs = qs.filter(Q(name__icontains=search) |
                           Q(roll_no__icontains=search) |
                           Q(email__icontains=search))
        if dept:
            qs = qs.filter(department=dept)
        return qs

    def list(self, request, *args, **kwargs):
        qs = self.get_queryset()
        return Response({"count": qs.count(),
                         "results": self.get_serializer(qs, many=True).data})

    @action(detail=False, methods=["get"])
    def stats(self, request):
        qs = Student.objects.all()
        total = qs.count()
        active = qs.filter(status="Active").count()
        return Response({
            "total": total,
            "active": active,
            "inactive": total - active,
            "averageMarks": round(qs.aggregate(a=Avg("marks"))["a"] or 0, 1),
            "departments": qs.values("department").distinct().count(),
            "byDepartment": {r["department"]: r["c"] for r in
                             qs.values("department").annotate(c=Count("id"))},
        })
```

### config/urls.py
```python
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from students.views import StudentViewSet

router = DefaultRouter()
router.register(r"students", StudentViewSet, basename="student")

urlpatterns = [path("api/", include(router.urls))]
```

### config/settings.py — additions
```python
INSTALLED_APPS += ["rest_framework", "corsheaders", "students"]
MIDDLEWARE.insert(0, "corsheaders.middleware.CorsMiddleware")
CORS_ALLOWED_ORIGINS = ["http://127.0.0.1:5500", "http://localhost:5500"]

# never hard-code secrets (SOP §11)
import os
SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]
```

### Run
```bash
python manage.py makemigrations && python manage.py migrate
python manage.py runserver        # http://localhost:8000/api/students/
```

---

## B. Spring Boot (Java)

### Student.java
```java
@Entity @Table(name = "student")
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Size(min = 3, max = 80) private String name;
    @NotBlank @Column(unique = true, length = 20) private String rollNo;
    @NotBlank @Email @Column(unique = true, length = 120) private String email;
    @NotBlank private String department;
    @Min(1) @Max(4) private Integer year;
    @DecimalMin("0.0") @DecimalMax("100.0") private BigDecimal marks;
    @Pattern(regexp = "\\d{10}", message = "Phone must be exactly 10 digits.")
    private String phone;
    private String status = "Active";
    // getters and setters
}
```

### StudentController.java
```java
@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = {"http://localhost:5500", "http://127.0.0.1:5500"})
public class StudentController {

    private final StudentService service;
    public StudentController(StudentService service) { this.service = service; }

    @GetMapping
    public Map<String, Object> list(@RequestParam(required = false) String search,
                                    @RequestParam(required = false) String dept) {
        List<Student> rows = service.search(search, dept);
        return Map.of("count", rows.size(), "results", rows);
    }

    @GetMapping("/{id}")
    public Student one(@PathVariable Long id) { return service.get(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Student create(@Valid @RequestBody Student s) { return service.create(s); }

    @PutMapping("/{id}")
    public Student update(@PathVariable Long id, @Valid @RequestBody Student s) {
        return service.update(id, s);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }
}
```

### Exception handling → matching error bodies
```java
@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, Object> invalid(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors()
          .forEach(e -> errors.put(e.getField(), e.getDefaultMessage()));
        return Map.of("detail", "Validation failed", "errors", errors);
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, String> missing(NotFoundException ex) {
        return Map.of("detail", ex.getMessage());
    }

    @ExceptionHandler(DuplicateException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String, Object> duplicate(DuplicateException ex) {
        return Map.of("detail", "Conflict", "errors", ex.getErrors());
    }
}
```

### application.properties
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sms
spring.datasource.username=${DB_USER}
spring.datasource.password=${DB_PASSWORD}
spring.jpa.hibernate.ddl-auto=update
server.port=8000
```

---

## C. SQL schema (MySQL / PostgreSQL)

```sql
CREATE TABLE student (
    id          INTEGER PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(80)  NOT NULL,
    roll_no     VARCHAR(20)  NOT NULL UNIQUE,
    email       VARCHAR(120) NOT NULL UNIQUE,
    department  VARCHAR(30)  NOT NULL,
    year        SMALLINT     NOT NULL CHECK (year BETWEEN 1 AND 4),
    marks       DECIMAL(5,2) NOT NULL CHECK (marks BETWEEN 0 AND 100),
    phone       CHAR(10)     NOT NULL,
    status      VARCHAR(10)  NOT NULL DEFAULT 'Active',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE INDEX idx_student_dept ON student(department);
```

## D. Postman testing (SOP §10)

Import these as a collection and run in order:
1. POST valid body → expect 201, save `id` to a collection variable.
2. POST same body again → expect 409.
3. POST `{}` → expect 400 with per-field `errors`.
4. GET collection → expect 200 and `count >= 1`.
5. GET `/api/students/{{id}}/` → 200; GET `/api/students/999999/` → 404.
6. PUT `/api/students/{{id}}/` with changed marks → 200 and the new value.
7. PUT with `marks: 140` → 400.
8. DELETE `/api/students/{{id}}/` → 204; repeat → 404.
