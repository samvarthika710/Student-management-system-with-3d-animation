# REST API Reference — Student Management System

Base URL (local backend): `http://localhost:8000`
Content type: `application/json`

| Operation | Method | Endpoint | Success | Errors |
|---|---|---|---|---|
| Create | POST | `/api/students/` | 201 Created | 400, 409 |
| Read all | GET | `/api/students/` | 200 OK | — |
| Read one | GET | `/api/students/{id}/` | 200 OK | 404 |
| Update (full) | PUT | `/api/students/{id}/` | 200 OK | 400, 404, 409 |
| Update (partial) | PATCH | `/api/students/{id}/` | 200 OK | 400, 404, 409 |
| Delete | DELETE | `/api/students/{id}/` | 204 No Content | 404 |
| Search / filter | GET | `/api/students/?search=ana&dept=CSE` | 200 OK | — |
| Stats | GET | `/api/students/stats/` | 200 OK | — |

## Create — POST /api/students/

Request
```json
{
  "name": "Ananya Rao",
  "rollNo": "CS2026-001",
  "email": "ananya.rao@college.edu",
  "department": "CSE",
  "year": 3,
  "marks": 91,
  "phone": "9876543210",
  "status": "Active"
}
```

201 Created
```json
{
  "id": 1,
  "name": "Ananya Rao",
  "rollNo": "CS2026-001",
  "email": "ananya.rao@college.edu",
  "department": "CSE",
  "year": 3,
  "marks": 91,
  "phone": "9876543210",
  "status": "Active",
  "createdAt": "2026-09-17T09:14:02.881Z"
}
```

400 Bad Request
```json
{
  "detail": "Validation failed",
  "errors": {
    "name": "Name is required.",
    "email": "Enter a valid email address.",
    "marks": "Marks must be between 0 and 100."
  }
}
```

409 Conflict
```json
{ "detail": "Conflict", "errors": { "rollNo": "Roll number already exists." } }
```

## Read all — GET /api/students/

200 OK
```json
{ "count": 2, "results": [ { "id": 1, "name": "Ananya Rao", "…": "…" } ] }
```

## Read one — GET /api/students/1/

200 OK returns the single object. Unknown id:
```json
{ "detail": "Student with id 999999 not found" }
```

## Update — PUT /api/students/1/

Same body as create; returns 200 with the updated object including `updatedAt`.
`PATCH` merges the supplied fields onto the stored record before validating.

## Delete — DELETE /api/students/1/

204 No Content, empty body. Unknown id returns 404 with a `detail` message.

## Stats — GET /api/students/stats/

```json
{
  "total": 8,
  "active": 6,
  "inactive": 2,
  "averageMarks": 80.4,
  "departments": 7,
  "byDepartment": { "CSE": 2, "IT": 1, "ECE": 1 }
}
```

## Validation rules enforced server-side

- `name` — required, minimum 3 characters
- `rollNo` — required, unique across the table
- `email` — required, matches `^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$`, unique
- `department` — must be one of the allowed values
- `year` — integer 1–4
- `marks` — number 0–100
- `phone` — exactly 10 digits
- `status` — `Active` or `Inactive` (defaults to `Active`)
