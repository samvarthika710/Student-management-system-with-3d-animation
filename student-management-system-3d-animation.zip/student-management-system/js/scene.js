/* 3D animated background — three.js r128 */
/* ================= 3D BACKGROUND ================= */
(function(){
  if(!window.THREE) return;
  var cv=document.getElementById('bg3d');
  var css=function(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim()||'#6ee7ff';};
  var renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  var scene=new THREE.Scene();
  var cam=new THREE.PerspectiveCamera(60,1,.1,2000); cam.position.z=340;
  function size(){var w=innerWidth,h=innerHeight;renderer.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix();}
  size(); addEventListener('resize',size);

  var pg=new THREE.BufferGeometry(),N=1500,pos=new Float32Array(N*3);
  for(var i=0;i<N*3;i++) pos[i]=(Math.random()-.5)*1100;
  pg.setAttribute('position',new THREE.BufferAttribute(pos,3));
  var stars=new THREE.Points(pg,new THREE.PointsMaterial({color:new THREE.Color(css('--a1')),size:2.1,transparent:true,opacity:.65}));
  scene.add(stars);

  var shapes=[];
  function mk(geo,col,x,y,z,s){
    var m=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:new THREE.Color(col),wireframe:true,transparent:true,opacity:.34}));
    m.position.set(x,y,z); m.scale.setScalar(s); scene.add(m); shapes.push(m); return m;
  }
  mk(new THREE.IcosahedronGeometry(52,1),css('--a1'),-190,90,-60,1);
  mk(new THREE.TorusKnotGeometry(34,9,80,12),css('--a2'),200,-70,-30,1);
  mk(new THREE.OctahedronGeometry(40,0),css('--a3'),120,140,-150,1);
  mk(new THREE.CylinderGeometry(42,42,26,26,1,true),css('--a1'),-170,-130,-120,1);
  mk(new THREE.BoxGeometry(46,46,46),css('--a2'),0,-10,-260,1);

  var mx=0,my=0;
  addEventListener('pointermove',function(e){mx=(e.clientX/innerWidth-.5);my=(e.clientY/innerHeight-.5);});
  (function loop(t){
    requestAnimationFrame(loop); t=t*.001;
    stars.rotation.y=t*.035; stars.rotation.x=t*.012;
    shapes.forEach(function(s,i){
      s.rotation.x=t*(.18+i*.05); s.rotation.y=t*(.24+i*.04);
      s.position.y+=Math.sin(t*1.1+i)*.09;
    });
    cam.position.x+=(mx*80-cam.position.x)*.045;
    cam.position.y+=(-my*60-cam.position.y)*.045;
    cam.lookAt(0,0,0);
    renderer.render(scene,cam);
  })(0);
})();
