/* Student Management System — data layer, REST API layer, UI */
/* ================= STATE + PERSISTENCE ================= */
var DEPTS=['CSE','IT','ECE','EEE','MECH','CIVIL','AIML','MBA'];
var DB={students:[],nextId:1,log:[]};
var remote=null, DOC='app/roster';

function localSave(){try{localStorage.setItem('sms.v1',JSON.stringify({students:DB.students,nextId:DB.nextId}))}catch(e){}}
function localLoad(){try{var r=localStorage.getItem('sms.v1');return r?JSON.parse(r):null}catch(e){return null}}
function persist(){
  localSave();
  if(remote){ remote.doc(DOC).set({students:DB.students,nextId:DB.nextId}).catch(function(){}); }
}
function pill(txt,cls){var p=document.getElementById('storepill');p.textContent=txt;p.style.color=cls||'';}

(async function initStore(){
  pill('◍ local storage');
  var l=localLoad(); if(l&&l.students){DB.students=l.students;DB.nextId=l.nextId||1;renderAll();}
  if(!window.claude||!claude.use) return;
  try{
    var db=await claude.use('db'); if(!db) return;
    remote=db;
    var d=await db.doc(DOC).get().catch(function(){return null});
    if(d&&d.data&&Array.isArray(d.data.students)&&d.data.students.length){
      DB.students=d.data.students; DB.nextId=d.data.nextId||DB.students.length+1; renderAll();
    }
    pill('◉ cloud synced','var(--ok)');
    db.doc(DOC).onSnapshot(function(snap){
      if(snap&&snap.data&&Array.isArray(snap.data.students)){
        DB.students=snap.data.students; DB.nextId=snap.data.nextId||DB.nextId; renderAll();
      }
    });
  }catch(e){}
})();

/* ================= API LAYER (server-side rules) ================= */
var EMAIL=/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

function validate(b,id){
  var e={};
  if(!b||typeof b!=='object') return {_:'Request body must be a JSON object.'};
  if(!b.name||!String(b.name).trim()) e.name='Name is required.';
  else if(String(b.name).trim().length<3) e.name='Name must be at least 3 characters.';
  if(!b.rollNo||!String(b.rollNo).trim()) e.rollNo='Roll number is required.';
  if(!b.email||!String(b.email).trim()) e.email='Email is required.';
  else if(!EMAIL.test(String(b.email).trim())) e.email='Enter a valid email address.';
  if(!b.department) e.department='Department is required.';
  else if(DEPTS.indexOf(b.department)<0) e.department='Unknown department.';
  var y=Number(b.year); if(!b.year&&b.year!==0) e.year='Year is required.';
  else if(!Number.isInteger(y)||y<1||y>4) e.year='Year must be an integer 1–4.';
  var m=Number(b.marks); if(b.marks===''||b.marks==null) e.marks='Marks are required.';
  else if(isNaN(m)||m<0||m>100) e.marks='Marks must be between 0 and 100.';
  if(!b.phone||!String(b.phone).trim()) e.phone='Phone is required.';
  else if(!/^\d{10}$/.test(String(b.phone).trim())) e.phone='Phone must be exactly 10 digits.';
  if(b.status&&['Active','Inactive'].indexOf(b.status)<0) e.status='Status must be Active or Inactive.';
  return e;
}
function dup(b,id){
  var r=String(b.rollNo||'').trim().toLowerCase(), em=String(b.email||'').trim().toLowerCase();
  var hit=DB.students.find(function(s){return s.id!==id&&(String(s.rollNo).toLowerCase()===r||String(s.email).toLowerCase()===em)});
  if(!hit) return null;
  return String(hit.rollNo).toLowerCase()===r?{rollNo:'Roll number already exists.'}:{email:'Email already registered.'};
}
function clean(b){
  return {name:String(b.name).trim(),rollNo:String(b.rollNo).trim(),email:String(b.email).trim().toLowerCase(),
    department:b.department,year:Number(b.year),marks:Number(b.marks),phone:String(b.phone).trim(),
    status:b.status||'Active'};
}
function logit(method,path,code){
  DB.log.unshift({method:method,path:path,code:code,at:new Date().toLocaleTimeString()});
  if(DB.log.length>40) DB.log.pop();
  renderActivity();
}

/* the "backend": returns {status, data} */
function api(method,path,body){
  var t0=performance.now();
  var res=(function(){
    var base=path.split('?')[0].replace(/\/+$/,'/');
    var qs={}; (path.split('?')[1]||'').split('&').forEach(function(p){var kv=p.split('=');if(kv[0])qs[decodeURIComponent(kv[0])]=decodeURIComponent(kv[1]||'')});
    var mS=base.match(/^\/api\/students\/(\d+)\/?$/);
    var isColl=/^\/api\/students\/?$/.test(base);
    var isStats=/^\/api\/students\/stats\/?$/.test(base);

    if(isStats&&method==='GET') return {status:200,data:stats()};
    if(isColl){
      if(method==='GET'){
        var out=DB.students.slice();
        if(qs.search){var q=qs.search.toLowerCase();out=out.filter(function(s){return (s.name+s.rollNo+s.email).toLowerCase().indexOf(q)>=0})}
        if(qs.dept) out=out.filter(function(s){return s.department===qs.dept});
        return {status:200,data:{count:out.length,results:out}};
      }
      if(method==='POST'){
        var e=validate(body); if(Object.keys(e).length) return {status:400,data:{detail:'Validation failed',errors:e}};
        var d=dup(body,null); if(d) return {status:409,data:{detail:'Conflict',errors:d}};
        var rec=clean(body); rec.id=DB.nextId++; rec.createdAt=new Date().toISOString();
        DB.students.push(rec); persist();
        return {status:201,data:rec};
      }
      return {status:405,data:{detail:'Method not allowed on collection'}};
    }
    if(mS){
      var id=Number(mS[1]); var i=DB.students.findIndex(function(s){return s.id===id});
      if(i<0) return {status:404,data:{detail:'Student with id '+id+' not found'}};
      if(method==='GET') return {status:200,data:DB.students[i]};
      if(method==='PUT'||method==='PATCH'){
        var merged=method==='PATCH'?Object.assign({},DB.students[i],body):body;
        var e2=validate(merged,id); if(Object.keys(e2).length) return {status:400,data:{detail:'Validation failed',errors:e2}};
        var d2=dup(merged,id); if(d2) return {status:409,data:{detail:'Conflict',errors:d2}};
        var up=clean(merged); up.id=id; up.createdAt=DB.students[i].createdAt; up.updatedAt=new Date().toISOString();
        DB.students[i]=up; persist();
        return {status:200,data:up};
      }
      if(method==='DELETE'){ DB.students.splice(i,1); persist(); return {status:204,data:null}; }
      return {status:405,data:{detail:'Method not allowed'}};
    }
    return {status:404,data:{detail:'No route matches '+base}};
  })();
  res.ms=Math.max(1,Math.round(performance.now()-t0+Math.random()*9));
  logit(method,path,res.status);
  return res;
}
function stats(){
  var n=DB.students.length, act=DB.students.filter(function(s){return s.status==='Active'}).length;
  var avg=n?DB.students.reduce(function(a,s){return a+Number(s.marks)},0)/n:0;
  var byDept={}; DB.students.forEach(function(s){byDept[s.department]=(byDept[s.department]||0)+1});
  return {total:n,active:act,inactive:n-act,averageMarks:Math.round(avg*10)/10,departments:Object.keys(byDept).length,byDepartment:byDept};
}

/* ================= UI HELPERS ================= */
function el(h){var d=document.createElement('div');d.innerHTML=h.trim();return d.firstElementChild}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])})}
function toast(kind,title,msg){
  var t=el('<div class="toast '+kind+'"><div><b>'+esc(title)+'</b><small>'+esc(msg||'')+'</small></div></div>');
  document.getElementById('toasts').appendChild(t);
  setTimeout(function(){t.classList.add('out');setTimeout(function(){t.remove()},360)},3400);
}
function tilt(node,max){
  max=max||10;
  node.addEventListener('pointermove',function(e){
    var r=node.getBoundingClientRect();
    var x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
    node.style.transform='rotateY('+(x*max)+'deg) rotateX('+(-y*max)+'deg) translateZ(10px)';
  });
  node.addEventListener('pointerleave',function(){node.style.transform=''});
}

/* ================= RENDER: STATS + CHART ================= */
function renderStats(){
  var s=stats();
  var cfg=[['Total students',s.total,'👥'],['Active',s.active,'✅'],['Average marks',s.averageMarks,'📊'],['Departments',s.departments,'🏛️']];
  var host=document.getElementById('stats'); host.innerHTML='';
  cfg.forEach(function(c){
    var n=el('<div class="stat"><div class="ic">'+c[2]+'</div><div class="lbl">'+c[0]+'</div><div class="val">0</div></div>');
    host.appendChild(n); tilt(n,12);
    var target=Number(c[1])||0, v=n.querySelector('.val'), t0=null;
    (function step(ts){ if(!t0)t0=ts; var p=Math.min(1,(ts-t0)/850);
      v.textContent=(target%1?(target*p).toFixed(1):Math.round(target*p));
      if(p<1) requestAnimationFrame(step); else v.textContent=target;
    })(performance.now());
  });
}
function renderChart(){
  var by=stats().byDepartment, keys=Object.keys(by).sort(function(a,b){return by[b]-by[a]});
  var max=Math.max.apply(null,keys.map(function(k){return by[k]}).concat([1]));
  var h=document.getElementById('chart');
  if(!keys.length){h.innerHTML='<div class="empty"><div class="big">📭</div>No records yet — add a student or seed demo data.</div>';return}
  h.innerHTML=keys.map(function(k){
    return '<div style="margin-bottom:11px"><div style="display:flex;justify-content:space-between;font-size:12px"><b>'+esc(k)+
      '</b><span class="mono" style="color:var(--muted)">'+by[k]+'</span></div><div class="bar"><i data-w="'+(by[k]/max*100)+'"></i></div></div>';
  }).join('');
  requestAnimationFrame(function(){h.querySelectorAll('.bar i').forEach(function(b){b.style.width=b.dataset.w+'%'})});
}
function renderActivity(){
  var h=document.getElementById('activity'); if(!h) return;
  if(!DB.log.length){h.innerHTML='<div class="empty" style="padding:26px"><div class="big">🛰️</div>No API calls logged yet.</div>';return}
  h.innerHTML=DB.log.map(function(l){
    var good=l.code<400;
    return '<div style="display:flex;gap:9px;align-items:center;padding:7px 0;border-bottom:1px solid var(--border);font-size:12px">'+
      '<span class="code '+(good?'g':'r')+'" style="font-family:var(--f-mono);font-size:10.5px">'+l.code+'</span>'+
      '<span class="mono" style="font-weight:600">'+l.method+'</span>'+
      '<span class="mono" style="color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(l.path)+'</span>'+
      '<span class="mono" style="margin-left:auto;color:var(--dim);font-size:10px">'+l.at+'</span></div>';
  }).join('');
}

/* ================= RENDER: STUDENT CARDS ================= */
function filtered(){
  var q=(document.getElementById('q').value||'').toLowerCase().trim();
  var d=document.getElementById('fdept').value, st=document.getElementById('fstatus').value;
  var sb=document.getElementById('sortBy').value;
  var out=DB.students.filter(function(s){
    if(q&&(s.name+' '+s.rollNo+' '+s.email).toLowerCase().indexOf(q)<0) return false;
    if(d&&s.department!==d) return false;
    if(st&&s.status!==st) return false;
    return true;
  });
  out.sort(function(a,b){
    if(sb==='marks') return b.marks-a.marks;
    if(sb==='roll') return String(a.rollNo).localeCompare(String(b.rollNo));
    if(sb==='year') return a.year-b.year||String(a.name).localeCompare(String(b.name));
    return String(a.name).localeCompare(String(b.name));
  });
  return out;
}
function renderGrid(){
  var g=document.getElementById('grid'), list=filtered();
  if(!DB.students.length){
    g.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="big">🎓</div><div style="font-family:var(--f-display);font-size:17px;color:var(--text)">No students in the database</div><div style="margin-top:6px">Use <b>+ New Student</b> to run a POST, or seed demo data.</div></div>';
    return;
  }
  if(!list.length){g.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="big">🔍</div>No records match those filters.</div>';return}
  g.innerHTML='';
  list.forEach(function(s,i){
    var init=s.name.split(' ').map(function(w){return w[0]}).slice(0,2).join('').toUpperCase();
    var c=el(
      '<div class="fcard" style="animation-delay:'+(i*45)+'ms"><div class="flip">'+
      '<div class="face"><div class="av">'+esc(init)+'</div><div class="nm">'+esc(s.name)+'</div>'+
      '<div class="rl">'+esc(s.rollNo)+' · id #'+s.id+'</div>'+
      '<div class="bar"><i data-w="'+s.marks+'"></i></div>'+
      '<div class="meta"><span class="tag">'+esc(s.department)+'</span><span class="tag">Year '+s.year+'</span>'+
      '<span class="tag '+(s.status==='Active'?'ok':'off')+'">'+esc(s.status)+'</span></div></div>'+
      '<div class="face back">'+
      '<div class="rowk"><span>Email</span><span style="font-size:11px">'+esc(s.email)+'</span></div>'+
      '<div class="rowk"><span>Phone</span><span class="mono">'+esc(s.phone)+'</span></div>'+
      '<div class="rowk"><span>Marks</span><span class="mono">'+esc(s.marks)+' / 100</span></div>'+
      '<div class="rowk"><span>Dept · Year</span><span>'+esc(s.department)+' · '+s.year+'</span></div>'+
      '<div class="acts"><button class="btn sm primary" data-ed="'+s.id+'">✎ Edit</button>'+
      '<button class="btn sm danger" data-del="'+s.id+'">🗑 Delete</button>'+
      '<button class="btn sm ghost" data-back="1">↩</button></div>'+
      '</div></div></div>');
    c.addEventListener('click',function(e){
      if(e.target.closest('[data-ed]')) return openForm(s.id);
      if(e.target.closest('[data-del]')) return askDelete(s.id);
      c.classList.toggle('flipped');
    });
    c.querySelector('.face').addEventListener('pointermove',function(e){
      if(c.classList.contains('flipped'))return;
      var r=c.getBoundingClientRect(), x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      c.querySelector('.flip').style.transform='rotateY('+(x*13)+'deg) rotateX('+(-y*13)+'deg)';
    });
    c.addEventListener('pointerleave',function(){ if(!c.classList.contains('flipped')) c.querySelector('.flip').style.transform=''; });
    g.appendChild(c);
  });
  requestAnimationFrame(function(){g.querySelectorAll('.bar i').forEach(function(b){b.style.width=b.dataset.w+'%'})});
}
function renderDeptOptions(){
  var sel=document.getElementById('fdept'), cur=sel.value;
  sel.innerHTML='<option value="">All departments</option>'+DEPTS.map(function(d){return '<option>'+d+'</option>'}).join('');
  sel.value=cur;
}
function renderAll(){renderStats();renderChart();renderGrid();renderActivity();}

/* ================= FORM (create / update) ================= */
var FIELDS=[
  {k:'name',l:'Full name',t:'text',ph:'Ananya Rao'},
  {k:'rollNo',l:'Roll number',t:'text',ph:'CS2026-077'},
  {k:'email',l:'Email',t:'email',ph:'name@college.edu',full:true},
  {k:'department',l:'Department',t:'select',opts:DEPTS},
  {k:'year',l:'Year of study',t:'select',opts:[1,2,3,4]},
  {k:'marks',l:'Marks (0–100)',t:'number',ph:'88'},
  {k:'phone',l:'Phone (10 digits)',t:'text',ph:'9876543210'},
  {k:'status',l:'Status',t:'select',opts:['Active','Inactive'],full:true}
];
var editingId=null;
function openForm(id){
  editingId=id||null;
  var s=id?DB.students.find(function(x){return x.id===id}):null;
  document.getElementById('fTitle').textContent=s?'Edit student · id #'+s.id:'Add student';
  document.getElementById('fSub').textContent=s?'PUT /api/students/'+s.id+'/':'POST /api/students/';
  document.getElementById('form').innerHTML=FIELDS.map(function(f){
    var v=s?s[f.k]:'';
    var input=f.t==='select'
      ? '<select data-k="'+f.k+'">'+f.opts.map(function(o){return '<option '+(String(v)===String(o)?'selected':'')+'>'+o+'</option>'}).join('')+'</select>'
      : '<input data-k="'+f.k+'" type="'+f.t+'" placeholder="'+(f.ph||'')+'" value="'+esc(v)+'">';
    return '<div class="f '+(f.full?'full':'')+'" data-fk="'+f.k+'"><label>'+f.l+'</label>'+input+'<div class="err"></div></div>';
  }).join('');
  document.getElementById('formOv').classList.add('on');
  setTimeout(function(){var i=document.querySelector('#form input');i&&i.focus()},260);
}
function closeForm(){document.getElementById('formOv').classList.remove('on')}
function save(){
  var body={};
  document.querySelectorAll('#form [data-k]').forEach(function(i){body[i.dataset.k]=i.value});
  document.querySelectorAll('#form .f').forEach(function(f){f.classList.remove('bad');f.querySelector('.err').textContent=''});
  var r=editingId?api('PUT','/api/students/'+editingId+'/',body):api('POST','/api/students/',body);
  if(r.status===400||r.status===409){
    var errs=r.data.errors||{};
    Object.keys(errs).forEach(function(k){
      var f=document.querySelector('#form .f[data-fk="'+k+'"]');
      if(f){f.classList.add('bad');f.querySelector('.err').textContent=errs[k]}
    });
    toast('e',r.status+' '+(r.status===409?'Conflict':'Validation failed'),Object.values(errs)[0]||'Check the highlighted fields.');
    return;
  }
  closeForm(); renderAll();
  toast('s',r.status+' '+(r.status===201?'Created':'Updated'),r.data.name+' saved in '+r.ms+' ms.');
}

/* ================= DELETE ================= */
var delId=null;
function askDelete(id){
  var s=DB.students.find(function(x){return x.id===id}); if(!s) return;
  delId=id;
  document.getElementById('delTxt').innerHTML='DELETE /api/students/'+id+'/ — this removes <b>'+esc(s.name)+'</b> ('+esc(s.rollNo)+') from the database. This cannot be undone.';
  document.getElementById('delOv').classList.add('on');
}

/* ================= EVENTS ================= */
document.getElementById('addBtn').onclick=function(){openForm(null)};
document.getElementById('fClose').onclick=closeForm;
document.getElementById('fCancel').onclick=closeForm;
document.getElementById('fSave').onclick=save;
document.getElementById('formOv').addEventListener('click',function(e){if(e.target===this)closeForm()});
document.getElementById('form').addEventListener('keydown',function(e){if(e.key==='Enter')save()});
document.getElementById('dCancel').onclick=function(){document.getElementById('delOv').classList.remove('on')};
document.getElementById('dOk').onclick=function(){
  var r=api('DELETE','/api/students/'+delId+'/');
  document.getElementById('delOv').classList.remove('on');
  renderAll();
  toast(r.status===204?'s':'e',r.status+(r.status===204?' No Content':' Error'),r.status===204?'Record deleted.':(r.data&&r.data.detail));
};
['q','fdept','fstatus','sortBy'].forEach(function(id){
  var n=document.getElementById(id); n.addEventListener('input',renderGrid); n.addEventListener('change',renderGrid);
});
document.getElementById('nav').addEventListener('click',function(e){
  var b=e.target.closest('button[data-t]'); if(!b) return;
  this.querySelectorAll('button').forEach(function(x){x.classList.toggle('on',x===b)});
  document.querySelectorAll('.tab').forEach(function(t){t.classList.remove('on')});
  var tab=document.getElementById('t-'+b.dataset.t); tab.classList.add('on');
  if(b.dataset.t==='dash'){renderStats();renderChart()}
  scrollTo({top:0,behavior:'smooth'});
});
document.getElementById('themeBtn').onclick=function(){
  var cur=document.documentElement.getAttribute('data-theme');
  var next=cur==='light'?'dark':(cur==='dark'?'light':(matchMedia('(prefers-color-scheme: dark)').matches?'light':'dark'));
  document.documentElement.setAttribute('data-theme',next);
  try{localStorage.setItem('sms.theme',next)}catch(e){}
  toast('i','Theme switched','Now using the '+next+' palette.');
};
try{var th=localStorage.getItem('sms.theme'); if(th) document.documentElement.setAttribute('data-theme',th);}catch(e){}

/* seed + wipe */
var SEED=[
  ['Ananya Rao','CS2026-001','ananya.rao@college.edu','CSE',3,91,'9876543210','Active'],
  ['Vikram Iyer','IT2026-014','vikram.iyer@college.edu','IT',2,78,'9812345670','Active'],
  ['Meera Nair','EC2026-007','meera.nair@college.edu','ECE',4,85,'9900112233','Active'],
  ['Rahul Menon','ME2026-022','rahul.menon@college.edu','MECH',1,64,'9765432109','Inactive'],
  ['Sneha Patil','AI2026-005','sneha.patil@college.edu','AIML',3,96,'9123456780','Active'],
  ['Arjun Das','CV2026-031','arjun.das@college.edu','CIVIL',2,72,'9871230456','Active'],
  ['Divya Krishnan','CS2026-045','divya.k@college.edu','CSE',4,88,'9012345678','Active'],
  ['Farhan Ali','EE2026-019','farhan.ali@college.edu','EEE',1,69,'9345612789','Inactive']
];
document.getElementById('seedBtn').onclick=function(){
  var added=0;
  SEED.forEach(function(r){
    var res=api('POST','/api/students/',{name:r[0],rollNo:r[1],email:r[2],department:r[3],year:r[4],marks:r[5],phone:r[6],status:r[7]});
    if(res.status===201) added++;
  });
  renderAll(); toast(added?'s':'i','Seed complete',added+' records created, '+(SEED.length-added)+' skipped as duplicates.');
};
document.getElementById('wipeBtn').onclick=function(){
  if(!DB.students.length) return toast('i','Nothing to clear','The database is already empty.');
  var n=DB.students.length;
  DB.students.slice().forEach(function(s){api('DELETE','/api/students/'+s.id+'/')});
  renderAll(); toast('s','Database cleared',n+' records deleted.');
};

/* ================= API CONSOLE ================= */
var METHOD='GET';
document.getElementById('mrow').addEventListener('click',function(e){
  var b=e.target.closest('.mbtn'); if(!b) return;
  METHOD=b.dataset.m;
  this.querySelectorAll('.mbtn').forEach(function(x){x.classList.toggle('on',x===b)});
  var ep=document.getElementById('ep');
  if(METHOD==='GET') ep.value='/api/students/';
  else if(METHOD==='POST') ep.value='/api/students/';
  else { var f=DB.students[0]; ep.value='/api/students/'+(f?f.id:1)+'/'; }
});
document.getElementById('fillBtn').onclick=function(){
  var f=DB.students[0];
  if(!f) return toast('i','No records','Seed demo data first.');
  document.getElementById('ep').value='/api/students/'+f.id+'/';
  document.getElementById('body').value=JSON.stringify({name:f.name,rollNo:f.rollNo,email:f.email,department:f.department,year:f.year,marks:f.marks,phone:f.phone,status:f.status},null,2);
  toast('i','Autofilled','Loaded record #'+f.id+' into the request.');
};
function paint(o){
  var j=JSON.stringify(o,null,2);
  return esc(j)
    .replace(/&quot;([^&]+)&quot;:/g,'<span class="k">"$1"</span>:')
    .replace(/: &quot;([^&]*)&quot;/g,': <span class="s">"$1"</span>')
    .replace(/: (-?\d+\.?\d*)/g,': <span class="n">$1</span>')
    .replace(/: (true|false|null)/g,': <span class="b">$1</span>');
}
document.getElementById('sendBtn').onclick=function(){
  var ep=document.getElementById('ep').value.trim(), raw=document.getElementById('body').value;
  var body=null;
  if(METHOD==='POST'||METHOD==='PUT'){
    try{body=JSON.parse(raw)}catch(err){
      document.getElementById('rstat').style.display='none';
      document.getElementById('resp').innerHTML='<span style="color:var(--err)">JSONDecodeError: request body is not valid JSON</span>';
      return toast('e','Bad request body','The JSON could not be parsed.');
    }
  }
  document.getElementById('beamSlot').innerHTML='<div class="beam"></div>';
  document.getElementById('resp').textContent='// waiting for backend…';
  setTimeout(function(){
    var r=api(METHOD,ep,body);
    document.getElementById('beamSlot').innerHTML='';
    var names={200:'OK',201:'Created',204:'No Content',400:'Bad Request',404:'Not Found',405:'Method Not Allowed',409:'Conflict'};
    var st=document.getElementById('rstat'); st.style.display='flex';
    st.innerHTML='<span class="code '+(r.status<400?'g':'r')+'">'+r.status+' '+(names[r.status]||'')+'</span>'+
      '<span style="color:var(--muted)">'+r.ms+' ms</span><span style="color:var(--dim)">application/json</span>';
    document.getElementById('resp').innerHTML=r.data===null?'<span class="b">// 204 No Content — body intentionally empty</span>':paint(r.data);
    renderStats();renderChart();renderGrid();
    toast(r.status<400?'s':'e',METHOD+' '+r.status,ep);
  },430);
};

/* ================= TEST RUNNER ================= */
var CASES=[
  ['Create with valid data returns 201',function(){var r=api('POST','/api/students/',{name:'Test Kumar',rollNo:'TST-9001',email:'test.kumar@college.edu',department:'CSE',year:2,marks:75,phone:'9000000001',status:'Active'});this.id=r.data&&r.data.id;return r.status===201},'201'],
  ['Created record is persisted in the database',function(){return !!DB.students.find(function(s){return s.rollNo==='TST-9001'})},'found'],
  ['Create with missing mandatory fields returns 400',function(){return api('POST','/api/students/',{name:'',rollNo:'',email:'',department:'',year:'',marks:'',phone:''}).status===400},'400'],
  ['Create with invalid email returns 400',function(){return api('POST','/api/students/',{name:'Bad Email',rollNo:'TST-9002',email:'not-an-email',department:'IT',year:1,marks:50,phone:'9000000002'}).status===400},'400'],
  ['Marks above 100 rejected with 400',function(){return api('POST','/api/students/',{name:'Over Marks',rollNo:'TST-9003',email:'over@college.edu',department:'IT',year:1,marks:140,phone:'9000000003'}).status===400},'400'],
  ['Phone with wrong length rejected with 400',function(){return api('POST','/api/students/',{name:'Bad Phone',rollNo:'TST-9004',email:'phone@college.edu',department:'IT',year:1,marks:60,phone:'123'}).status===400},'400'],
  ['Duplicate roll number returns 409 Conflict',function(){return api('POST','/api/students/',{name:'Clone One',rollNo:'TST-9001',email:'clone1@college.edu',department:'CSE',year:2,marks:70,phone:'9000000005'}).status===409},'409'],
  ['Duplicate email returns 409 Conflict',function(){return api('POST','/api/students/',{name:'Clone Two',rollNo:'TST-9006',email:'test.kumar@college.edu',department:'CSE',year:2,marks:70,phone:'9000000006'}).status===409},'409'],
  ['Read all returns 200 with a count',function(){var r=api('GET','/api/students/');return r.status===200&&typeof r.data.count==='number'},'200'],
  ['Read one with a valid ID returns 200',function(){return api('GET','/api/students/'+this.id+'/').status===200},'200'],
  ['Read one with an invalid ID returns 404',function(){return api('GET','/api/students/999999/').status===404},'404'],
  ['Search filter narrows the result set',function(){return api('GET','/api/students/?search=Test%20Kumar').data.count>=1},'≥1'],
  ['Update with valid data returns 200 and new values',function(){var r=api('PUT','/api/students/'+this.id+'/',{name:'Test Kumar',rollNo:'TST-9001',email:'test.kumar@college.edu',department:'AIML',year:3,marks:93,phone:'9000000001',status:'Active'});return r.status===200&&r.data.marks===93&&r.data.department==='AIML'},'200'],
  ['Update with an invalid ID returns 404',function(){return api('PUT','/api/students/999999/',{name:'Ghost User',rollNo:'TST-0000',email:'ghost@college.edu',department:'IT',year:1,marks:10,phone:'9000000009'}).status===404},'404'],
  ['Update with invalid data returns 400',function(){return api('PUT','/api/students/'+this.id+'/',{name:'X',rollNo:'',email:'bad',department:'ZZZ',year:9,marks:-4,phone:'ab'}).status===400},'400'],
  ['Delete with a valid ID returns 204',function(){return api('DELETE','/api/students/'+this.id+'/').status===204},'204'],
  ['Deleted record is gone from the database',function(){return !DB.students.find(function(s){return s.rollNo==='TST-9001'})},'absent'],
  ['Delete with an invalid ID returns 404',function(){return api('DELETE','/api/students/999999/').status===404},'404'],
  ['Unknown route returns 404',function(){return api('GET','/api/teachers/').status===404},'404'],
  ['Stats endpoint aggregates correctly',function(){var r=api('GET','/api/students/stats/');return r.status===200&&r.data.total===DB.students.length},'200']
];
document.getElementById('runBtn').onclick=function(){
  var ctx={}, list=document.getElementById('tlist'), pass=0, i=0;
  list.innerHTML=''; document.getElementById('tprog').style.width='0%';
  var nodes=CASES.map(function(c){
    var n=el('<div class="tcase"><span class="dot"></span><span>'+esc(c[0])+'</span><span class="exp">expects '+esc(c[2])+'</span></div>');
    list.appendChild(n); return n;
  });
  (function step(){
    if(i>=CASES.length){
      document.getElementById('tsummary').innerHTML=pass+' / '+CASES.length+' test cases passed · '+
        (pass===CASES.length?'<span style="color:var(--ok)">ALL GREEN</span>':'<span style="color:var(--err)">FAILURES PRESENT</span>');
      renderAll(); toast(pass===CASES.length?'s':'e','Test run finished',pass+' of '+CASES.length+' passed.');
      return;
    }
    var ok=false; try{ok=!!CASES[i][1].call(ctx)}catch(e){ok=false}
    if(ok) pass++;
    nodes[i].classList.add(ok?'pass':'fail');
    nodes[i].querySelector('.exp').textContent=ok?'PASS':'FAIL';
    nodes[i].querySelector('.exp').style.color=ok?'var(--ok)':'var(--err)';
    i++;
    document.getElementById('tprog').style.width=(i/CASES.length*100)+'%';
    document.getElementById('tsummary').textContent='Running… '+i+'/'+CASES.length;
    setTimeout(step,110);
  })();
};

/* ================= DEMO CHECKLIST ================= */
var CHK=['Application starts without errors','Database connection works correctly','Create operation works','Read / list operation works',
'Update operation works','Delete operation works','Validation works on client and server','Search / filter works',
'API endpoints can be demonstrated','Architecture and code flow can be explained','Source code and documentation submitted'];
(function(){
  var saved={}; try{saved=JSON.parse(localStorage.getItem('sms.chk')||'{}')}catch(e){}
  var h=document.getElementById('chks');
  h.innerHTML=CHK.map(function(c,i){
    return '<label class="chk"><input type="checkbox" data-i="'+i+'" '+(saved[i]?'checked':'')+'><span>'+esc(c)+'</span></label>';
  }).join('');
  h.addEventListener('change',function(e){
    saved[e.target.dataset.i]=e.target.checked;
    try{localStorage.setItem('sms.chk',JSON.stringify(saved))}catch(err){}
  });
})();

/* ================= BOOT ================= */
renderDeptOptions(); renderAll();
document.querySelectorAll('.layer').forEach(function(l,i){
  l.addEventListener('pointerenter',function(){l.style.filter='brightness(1.35)'});
  l.addEventListener('pointerleave',function(){l.style.filter=''});
});
addEventListener('load',function(){setTimeout(function(){document.getElementById('pre').classList.add('gone')},520)});
setTimeout(function(){document.getElementById('pre').classList.add('gone')},2600);
